# S5 paper and data artifact

Sound and Deterministic Quadric Arrangements on a Rational Ellipsoid with Machine-Checkable Certificates

- Code: not included in this record.
- Companion paper: `10.5281/zenodo.23721477`

## Contents

- `papers/`: S5 PDF and source
- `data/`: artifact data, tables, and test vectors

## License

- Paper text and artifact data: **CC BY 4.0**.
- Research code and Lean proofs are not included in this record.
- Axiom product core, MCP server, CLI, and CA keys: **not included**.

## Product boundary

The Axiom product is separate from this artifact. Its licensing is not
determined by this artifact. No proprietary A' source or signing key is included.
