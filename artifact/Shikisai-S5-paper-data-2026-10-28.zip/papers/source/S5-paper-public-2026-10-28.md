# Sound and Deterministic Quadric Arrangements on a Rational Ellipsoid with Machine-Checkable Certificates

> **Shikisai Project** · Independent research and tools project  
> Contact: https://github.com/ShikisaiProject · X: @shikisaipj  
> Preprint v1.2 — 2026-10-27

## Abstract

We present a deterministic arrangement kernel for rational quadric surfaces on a rational
ellipsoid, built on exact rational and algebraic arithmetic. Intersection curves are pulled
back to the plane through a rational stereographic atlas of the ellipsoid, and
two-dimensional algebraic curve arrangements are computed with resultants, subresultants,
and univariate root isolation. Every rejected input carries a classified
`NoneReason` (a machine-readable label, not a per-input certificate); on our scoped benchmark
all 378 single-chart failures are classified as
unbounded charts (364) or confluent components (14), with zero unclassified cases. A
deterministic atlas of six axial and twenty-four general poles reduces the residual
all-chart rejection rate on a 2–3 plane family from 14.98% at coefficient height `H=1` to 0.64% at `H=3`, 0.020%
at `H=10`, and 0.000% at `H=20`, an empirical `O(1/H)` trend rather than a theorem. For 20
mixed quartic pullbacks, the standard chart closes 14; the 6+24 chart search with a 3D
face-point check and the single-safe-chart 2D lift both close and certify all 20, with
strict loop-boundary 20/20 and last-resort 3D check 0/20. On our fixed-seed families, a
20-case three-quadric pilot is 20/20 via the hybrid path
(single-chart plus exact rational linear-transform and basis fallbacks), certified and
strict 20/20; a 100-case three-quadric stress test closes 100/100 with 100/100 certified
and strict and no timeout. We also report 3/4/5/6-plane lifts in
20/20 cases each, certified and strict; seven or more planes are rejected by the certified
API. Accepted
outputs are independently checkable by a certificate checker. Here "certified" means that
the output passes that checker (Euler, exact face signs, rotation system, and the strict
loop-boundary invariants); it does not assert event completeness. A Lean-checked
combinatorial core, extracted-data checks, and Mathlib proofs of the cusp sign and
boundedness principle are included. We do not claim unconditional completeness or full
formal verification of the arrangement kernel.

## 1. Introduction

### 1.1 Motivation

Implicit and CSG-based design pipelines rely on quadric primitives such as spheres,
ellipsoids, cylinders, cones, and general quadrics. Boolean evaluation requires the
arrangement of their boundary surfaces: a decomposition into vertices, edges, faces, and
cells with consistent labels. Floating-point implementations are fragile at tangencies,
coplanar contacts, shared components, and surfaces passing through a parameterization
pole. Exact arithmetic removes rounding, but introduces expensive algebraic numbers and
makes cross-environment determinism difficult.

This paper asks a narrower question than "solve arbitrary CSG": can we build a small,
auditable arrangement kernel for rational quadrics that is exact, deterministic,
fail-closed, and reproducible, with an explicit account of what it does not solve?

### 1.2 Problem and challenges

We consider a rational ellipsoid `E` and a finite set of rational quadrics. The kernel must
compute their arrangement on `E`, lift the 2D arrangement to 3D boundary edges and faces,
attach exact face labels, and reject unsupported or undecided configurations soundly. The
certified API returns only outputs that pass the certificate gate.

The main difficulties are unbounded pullbacks (a chart pole on a curve), degeneracies
(common components, ordinary cusps, vertical tangencies), algebraic-number ordering and
membership, and determinism across machines and runs.

### 1.3 Approach

We use a rational multi-chart atlas:

1. Parameterize `E` by a rational stereographic map from a pole `P`.
2. Pull each quadric back to a polynomial `F_P(u,v)` of degree at most four.
3. If the excluded pole is not on the quadric, the pullback is bounded; otherwise try
   another chart from a deterministic atlas of six axial and twenty-four general poles.
4. Compute the 2D arrangement with resultants, subresultants, and univariate root
   isolation.
5. Lift the accepted single-chart arrangement to 3D and attach exact face labels. The
   current implementation does **not** stitch different charts; the atlas is a candidate
   pool, and each successful candidate is reconstructed in one chart.
6. If no chart works, or a degeneracy cannot be resolved, return
   `Rejected(None(reason))` with a classified `NoneReason`.

Two reconstruction modes share the same 6+24 candidate pool. The **single-chart 2D lift**
uses the certified 2D labels and compactifies the unbounded face at the pole. The
**3D-face-check mode** lifts the face sample points to `E` and verifies their signs in 3D;
it is a validation mode, not a multi-chart stitch. Neither mode combines different charts
in one output. Genuine multi-chart stitching is future work (OP2).

### 1.4 Contributions

| ID | Contribution | Evidence |
|---|---|---|
| C1 | All geometric predicates and topology use exact rational/algebraic arithmetic; f64 is confined to candidate generation. | code, determinism tests |
| C2 | Every rejection has a classified `NoneReason` (a label, not a per-input certificate); 378/378 classified, zero unclassified on the scoped benchmark. | artifact, Lean totality model |
| C3 | Deterministic 6+24 pole atlas over classical stereographic charts on the 2–3 plane family; residual all-chart rejection 14.98% -> 0.64% -> 0.020% -> 0.000% for `H=1,3,10,20` (empirical). | artifact, ablation |
| C4 | Quartic pullbacks: 2-quadric 20-case benchmark: standard 14/20; 6+24 chart search with 3D face-point check 20/20 certified; single-chart 2D lift 20/20 certified + strict 20/20; last-resort 3D check 0/20. 3-quadric 20-case pilot: 20/20 hybrid, certified + strict 20/20. A 100-case 3-quadric stress test closes 100/100, certified + strict 100/100, with no timeout under the 300 s/case harness; 61 cases use the primary single-chart path and 39 use exact rational linear-transform/basis fallbacks. The claim remains empirical on the fixed-seed family, not an unconditional three-quadric theorem. | artifact |
| C5 | A specific exact membership test (dynamic zero test) without bivariate GCD or algebraic-number arithmetic; counterexample regressions. The general avoidance of irrational numbers is prior work [Caravantes–Gonzalez-Vega 2008]. | tests |
| C6 | `GL(2)`-invariant Segre key and exact comparison for the handled pairs (not a new QSIC classification). | tests, related work |
| C7 | Deterministic cusp merging via the exact branch-side sign `delta^2 = -x^3 T_3/(3 F_vv^4)`. | Rust regression, Mathlib proof |
| C8 | Cost-aware algebraic-number arithmetic with guards. | timing tests |
| C9 | Certified 3D lift for an ellipsoid plus up to six planes: 3/4/5/6-plane 20/20 cases pass a scoped certificate and strict check; max `V/E/F` is 12/18/8 (3), 20/32/14 (4, C1), 30/50/22 (5), 42/72/32 (6). Seven or more planes are rejected by the certified API. | artifact, gate |
| C10 | Accepted outputs are independently checkable by a certificate checker (Euler, exact face signs, rotation system). | checker, tamper tests |
| C11 | Lean-checked combinatorial core, Rust-to-Lean extraction, and Mathlib proofs of the cusp sign and boundedness principle. | Lean development (not included) |
| C12 | Deterministic, reproducible artifacts (SHA-256, CI, fixed seeds). | artifacts, CI |

### 1.5 Positioning and non-claims

We do not claim a new arrangement algorithm or a new classification of quadric
intersection curves. Prior work establishes exact 3D quadric arrangements, complete planar
maps of quadric intersection curves, exact cell computation including degenerate cases,
exact low-degree curve arrangements, general exact arrangement frameworks, exact boundary
evaluation, isotopy-guaranteed implicit meshing, and a complete QSIC classification. Prior
work also establishes exact quartic and higher-degree curve arrangements
(Caravantes–Gonzalez-Vega 2007, 2008; Eigenwillig et al. 2006), arrangements on parametric
surfaces and stereographic parameterizations (Berberich et al. 2007, 2010; Wang–Joe–Goldman
1997), exact spherical arrangements (Cazals–Loriot 2009; de Castro et al. 2009; Fogel 2009),
formal-methods CSG (Tzoumas et al. 2015), and certifying algorithms (McConnell et al. 2011;
Li–Passmore–Paulson 2019).
Our contribution is the combination of guarantees: deterministic execution, fail-closed
rejection certificates, a rational atlas for unbounded pullbacks, empirical completeness
on a scoped benchmark, an independent certificate checker, and a partially formalized
combinatorial core.

We do not claim unconditional completeness, a solution for four general quadrics, a
certified solution for seven or more planes, full formal verification of the arrangement kernel, or that
`O(1/H)` is a theorem.

### 1.6 Roadmap

Section 2 fixes scope and semantics. Section 3 describes the method. Section 4 states
soundness and determinism. Section 5 reports the completeness benchmark. Section 6 covers
3D arrangements and applications. Section 7 states limitations. Section 8 positions the
work. Section 9 documents reproducibility.

### 1.7 Scope and open problems

This paper focuses on a scoped class: rational quadric surfaces on a rational ellipsoid,
with certified output on the stated benchmark. Complete resolution for arbitrary rational
quadrics (no chart or cost assumption, all degeneracies) is not claimed. Open problems
include a general proof of the strict loop-boundary certificate (the benchmark check
passes), multi-chart stitching when no common safe chart exists, general four-quadric
scenes, and unconditional termination and cost bounds. Lean
coverage is partial and is treated as a verification aid, not as full formalization.

## 2. Scope and Semantics

### 2.1 Input and output

**Input.** A rational ellipsoid `E` and rational quadrics `Q_1,...,Q_n`. The base ellipsoid
admits a rational stereographic parameterization. Coefficients are exact integers or
rationals.

**Output.** A boundary complex on `E`: vertices with exact algebraic coordinates and
incidence metadata; edges labeled by their supporting quadric; faces with a sign vector in
`{-1,0,+1}^n`; a rotation system; component count and Euler data. The output is an
arrangement kernel, not a full CSG solid.

### 2.2 Exact arithmetic and the f64 boundary

All predicates and combinatorial decisions use exact rational or algebraic arithmetic.
Floating point is used only to generate candidate charts, seed isolating intervals, and
estimate costs. A candidate is never accepted on a floating-point test. If an exact
decision cannot be made within the cost budget, the result is `Rejected(None(reason))`.

### 2.3 Failure semantics

Every rejection carries a `NoneReason`: `NonBoundedChart`, `CommonComponent`,
`TangentialIntersection`, `SingularPoint`, `FaceCycleInvalid`, `OutOfScope`, or
`BudgetExceeded`. `OutOfScope` is used for inputs outside the validated API scope (for
example seven or more planes) and is never a geometric failure. `BudgetExceeded` is the
fail-closed result of the deterministic `SurveyBudget`; it is distinct from
`CommonComponent`. `Undetermined` is a sentinel for a missing classification; the kernel
must not return it for a known rejection. The Lean totality model mirrors the Rust
constructors (`nonBounded`, `commonComponent`, `tangential`, `singular`, `faceCycleInvalid`,
`outOfScope`, `budgetExceeded`, `undetermined`), and its classification proof covers the
same finite set.
On the scoped benchmark the single-chart diagnostic records 378 rejections (364
non-bounded, 14 confluent components) and zero unclassified cases. The product-geometry
run over circles and ellipsoid-plane pullbacks has no general-position rejection. The Lean
model proves that a classified `RejectReason` maps to a non-`undetermined` `NoneReason`.

### 2.4 Claim boundary

The paper claims soundness of accepted outputs on the scoped benchmark, practical
completeness via the atlas, exact 3D arrangements for an ellipsoid plus up to six planes,
and deterministic reproducible artifacts. It does not claim completeness for seven or more
planes, four general quadrics, mesh fidelity, unconditional formal verification, or a new
QSIC classification.

## 3. Method

### 3.1 Rational parameterization and bounded pullbacks

For the unit sphere, the rational stereographic map from the north pole is

```text
phi^{-1}(u,v) = ( 2u/(1+u^2+v^2), 2v/(1+u^2+v^2), (1-u^2-v^2)/(1+u^2+v^2) ).
```

A general ellipsoid is handled by an affine map. For a quadric `Q`, define

```text
F_{P,Q}(u,v) = Q(phi_P^{-1}(u,v)) * (1+u^2+v^2)^2,
```

a polynomial of degree at most four. Its leading homogeneous part is
`Q(P) * (u^2+v^2)^2`, where `P` is the excluded point (the chart pole). We use "chart
pole" and "excluded point" interchangeably. If `Q(P) != 0`, the real zero set is bounded.
This is the boundedness reduction; the analytic core is formalized in Mathlib.

### 3.2 Deterministic multi-chart atlas

The atlas has six axial poles and twenty-four general poles with coordinates
`(+/-1,+/-2,+/-2)/3` and permutations. A pole is safe if `Q_i(P) != 0` for every `i`. The
kernel tries the atlas in a fixed order and uses the first safe chart that yields a
certified 2D arrangement. If no chart is safe, the result is `NonBoundedChart`.

The atlas is not a completeness theorem. On a random benchmark a common safe pole exists
in 2000/2000 two-to-three-plane cases; a synthetic worst case with 30 covering planes has
zero safe poles. The residual all-chart rejection rate over 5000 fixed-seed plane cases is
14.98% at `H=1`, 0.64% at `H=3`, 0.020% at `H=10`, and 0.000% at `H=20`; this is empirical.

**Exact 2D chart transforms.** When a safe chart still produces an ill-conditioned
pullback, the kernel may compose it with one of a fixed list of exact invertible 2D maps
`M`: rational rotations `(3/5,4/5)` and `(5/13,12/13)`, shears `(1,1;0,1)` and
`(1,0;1,1)`, and three determinant-`+/-2` maps. The transformed curve is `F o M`; the
2D topology is unchanged because `M` is an affine homeomorphism. The same `M` maps face
points and vertices back to the base chart before 3D lifting, and each candidate must pass
both the normal and strict certificates. The list is deterministic and fixed, not tuned
per input; it is a tractability fallback, not part of the completeness argument. We
deliberately do not order it by degree or coefficient size: an input-dependent order would make
the accepted set depend on a heuristic, whereas the fixed order keeps two runs comparable.

### 3.3 Two-dimensional algebraic curve arrangement

The 2D core computes critical points from `F = F_v = 0`, pairwise intersections from
resultants and subresultants, events and slabs, x-monotone arcs, face cycles, and face
sign vectors at rational sample points. Real algebraic numbers are represented by a
defining polynomial and an isolating interval (`AlgRoot`). Comparisons refine intervals
until they separate; cost guards bound algebraic multiplication/addition. Every reported root
carries an isolating interval, but we do not claim a separation bound that would guarantee that
every event is found: the budget bounds work, not correctness, and a missed event remains a
failure mode outside the certificate (Section 4.3, OP1).

**Deterministic survey budget.** To make the resource bound reproducible and independent
of wall-clock time, the survey carries a `SurveyBudget`: maximum input and intermediate
coefficient bits, maximum resultant matrix dimension, maximum root-isolation work units,
maximum fiber refinements, and maximum `AlgRoot` comparison refinements. The budget is
checked inside the Bareiss elimination, before square-free/GCD operations, in root
isolation, and in the branch classifier. Exceeding it yields `BudgetExceeded` (fail
closed), never a partial arrangement and never `CommonComponent`. The public `planar_arrangement_n` uses a wide default; the search
uses a tight budget for three-or-more-surface primary candidates and wider budgets for
transformed and basis candidates. The thresholds are engineering constants, not a
complexity theorem.

**Face sample points.** Each face receives a rational sample point as follows. For an
edge on a face cycle, take its slab and the branch index. The `u` coordinate is the
rational midpoint of the slab, and the `v` coordinate is a rational point strictly between
the branch and the next branch above/below (or between the branch and `+/-1` at the slab
boundary). The point is therefore strictly inside the slab and strictly between two
consecutive branches, hence inside the face; the kernel evaluates every curve at this point
and rejects any zero. If no candidate point gives a nonzero sign vector, the arrangement
fails closed.

### 3.4 Degeneracies and rejection certificates

**Common components.** A Gauss gate uses `content_v`, self-resultants, and pair
resultants to detect shared components before the sweep. Detected cases are rejected as
`CommonComponent`; the gate is sound. A separate fallback constructs a set-theoretic
square-free coprime basis instead of rejecting the chart: it removes non-real `u`-only
content, normalizes in `v`, and splits shared factors with a primitive PRS GCD. The basis
has the same real zero set as the original curves. The 2D arrangement is built from the
basis, but face labels are recomputed from the original quadrics, and the result is
certified against the original pullbacks with both the normal and strict checks. This
handles `self_resultant` charts without claiming support for true shared components. The division
of labour is therefore explicit: the gate rejects on the original pullbacks (fast and sound) in
the paths that do not build a basis, whereas the basis stage separates a shared or repeated
factor `h` into its own curve (`f = h a`, `g = h b` gives `h, a, b`) and certifies against the
original quadrics. The 14 `CommonComponent` counts in Section 5.2 come from the single-chart
diagnostic, which does not invoke the basis stage.

**Ordinary cusps.** Let `x = u - u_c` and let `delta` be the offset from the repeated
tangent direction; `T_3` is the third-order tangent derivative. For a point with
`F=F_u=F_v=0`, discriminant `D=0`, `F_vv != 0`, and `T_3 != 0`, the two local branches
satisfy

```text
delta^2 = - x^3 T_3 / (3 F_vv^4).
```

Since `F_vv^4 > 0` and `3 > 0`, the sign is determined by `-x^3 T_3`. For `x>0`, `T_3<0`
gives the right branch and `T_3>0` the left branch. The kernel merges the ordinary cusp
into the fold-point path using this exact sign. The sign lemmas and the normal form are
proved in Mathlib.

**Exact membership.** To decide `f(alpha,beta)=0` for independent algebraic numbers, the
kernel uses univariate resultants, GCDs, and dynamic zero-divisor handling rather than
bivariate GCD or algebraic-number arithmetic. Counterexamples from earlier prototypes are
kept as regression tests.

**Segre key.** For pair classification, a `GL(2)`-invariant Segre key is computed with a
non-singular gauge and univariate determinantal divisors. This key is used only for the
handled cases; we do not claim a new QSIC classification.

### 3.5 3D assembly and the single-safe-chart lift

The 2D arcs are lifted to 3D edges; face cycles are assembled from the rotation system;
each face carries a sign vector. For an ellipsoid plus three planes, the kernel closes and
certifies 20/20 general-position cases with max `V/E/F = 12/18/8`.

For a scene with a common safe chart, the single-safe-chart path avoids 3D stitching: it
lifts the certified 2D arrangement directly to `E`, adds the pole to the unbounded face,
and uses the exact 2D labels. This handles empty quadrics (no real intersection with `E`)
and self-intersecting space curves (case 17 has a figure-eight node) through the 2D
pullback. The **3D-face-check mode** uses the same single chart but verifies face sample
points and labels in 3D; it is a validation mode, not a multi-chart stitch. If neither mode
accepts, the kernel returns a rejection. The certified API for planes covers up to six
planes; seven or more are rejected as `OutOfScope` (a scope label, not a face-cycle
failure). The gate is neither a geometric failure nor a budget cutoff: `BudgetExceeded` is
reserved for exhaustion inside the deterministic `SurveyBudget` (Section 3.3), whereas the plane
API stops at the largest corpus for which the same certificate has been validated (3/4 planes
originally, 5/6 planes at 20/20 each). Returning `OutOfScope` keeps the two causes separate
instead of reporting a resource exhaustion that did not occur.

**Proposition 1 (single-chart lift).** If `P` is a common safe pole (`Q_i(P) != 0` for all
`i`) and the 2D arrangement of the pullbacks passes the exact 2D certificate, then its lift
to `E`, with `P` added to the unbounded face, is a cell decomposition of `E` with exact
signed labels. Proof sketch: the stereographic projection is a homeomorphism from
`E \ {P}` to `R^2`; `P` lies on no curve; the unbounded face compactifies at `P`; labels are
exact at rational face points and verified at 3D face points. Generalizing this to
multi-chart stitching is future work. The 2D unbounded face is compactified at `P`; the
2D Euler relation `V-E+F=1+C` is preserved, and for a connected arrangement `C=1` this is
the sphere value `2`. No extra vertex is added at `P`.

### 3.6 Determinism and cost

All combinatorial containers use `BTreeMap`/`BTreeSet` or explicitly sorted vectors.
Random seeds are fixed. Floating point never decides a predicate. Artifacts are raw bytes
with SHA-256 records, and CI checks byte stability. Costs are dominated by algebraic-number
comparisons and resultants; the kernel uses cost guards and reports measured timings.

## 4. Soundness and Determinism

### 4.1 Exact layers and the floating-point boundary

The exact layer is `BigRational` (`Q`, rationals), `AlgRoot` (algebraic numbers with defining polynomial
and isolating interval), and `PolyUV` (bivariate polynomials). Predicates are sign
evaluation at rational points, exact algebraic comparison, nonzero tests for resultants
and contents, polynomial GCDs, and membership tests. Floating point is used only for
candidate generation and cost estimates.

### 4.2 Outcomes

The kernel has three outcomes:

1. `Accepted(Some(arrangement))`: a boundary complex with vertices, edges, faces, labels,
   and a rotation system.
2. `Rejected(None(reason))`: a sound rejection with a classified `NoneReason`.
3. `Undetermined`: a rejection whose reason is not yet classified.

### 4.3 Soundness of accepted outputs

Acceptance is not a claim of global completeness. The independent checker validates the
face-cycle chain and half-edge pairing, Euler `V-E+F=1+C`, exact signs at rational face
points, rotation coverage, and vertex metadata. Tampered labels, component counts, and
rotation systems are rejected. A strict loop-boundary checker additionally evaluates
non-incident curve signs at loop vertices with exact rational interval enclosures; it
passes 20/20 on 3/4/5/6-plane and 2-quadric benchmarks, and 100/100 on the 3-quadric
100-case stress family. For extracted Rust data, Lean
verifies closure and Euler on
five scenes; negative controls are rejected. This is a certificate for accepted outputs,
not a proof that the generator always accepts.

**Proposition 2 (strict boundary certificate).** Assume the arrangement is correct in the
following structural sense: its edges are maximal arcs whose interiors meet `C` only at
vertices, `F` is a connected component of the arrangement complement, and `C` is a union of
arrangement edges. Suppose every boundary vertex of `F` not incident to `C` has the same
nonzero sign `s`, and the face label for `C` is `s`. Then `F` lies in the open region
`sign(C)=s`.

Proof sketch: under the structural assumption, an edge cannot cross `C` in its interior;
it meets `C` only at incident vertices. Hence the sign of `C` is locally constant along the
boundary away from incident vertices, and the boundary lies in the closure of the
sign-`s` region. Since `F` is connected and disjoint from `C`, `F` is contained in that
region.

The strict checker verifies the vertex-level consequent of this proposition on the
constructed face cycles. It is a **post-hoc consistency check**, not a proof of the
structural assumption. If every boundary vertex is incident to `C` (for example, a digon
lens bounded by two curves), the non-incident set is empty and the exact face-point sign
check decides the label. The Lean file `S5Strict.lean` formalizes the local checker; the
geometric bridge and the edge-splitting assumption are paper-level and are not fully
formalized (see OP1).

| Checker detects | Relies on the structural premise |
|---|---|
| face-label / non-incident vertex sign mismatch | an edge interior crossing `C` |
| Euler / component-count mismatch | missed root isolation or event handling |
| rotation-system / open-edge mismatch | incorrect edge splitting |
| tampered face, label, or rotation system | global Jordan/connectedness |

**What the strict checker does not see.** The checker is post-hoc: it assumes that the
arrangement's edges are maximal arcs and that root isolation did not miss an event. If two
curves form a tiny digon lens and both intersection vertices are missed, the resulting
face cycle can still satisfy Euler and the vertex-level sign checks; the non-incident set
may even be empty. This is why the structural premise (OP1) is stated explicitly and why
the strict check is not a completeness proof for the arrangement generator.

**Rational chart transforms.** Let `M` be an invertible `2 x 2` rational matrix and
`F' = F o M`. Since `M` is an affine homeomorphism of `R^2`, it induces a bijection on
zero sets, vertices, arcs, faces, and face adjacency. The kernel enumerates the same
combinatorial arrangement after applying `M^{-1}` to the stored coordinates; an accepted
candidate must still pass the certificate against the transformed pullbacks.

**Square-free coprime basis.** Replacing a curve family by a square-free coprime basis
preserves the union of real zero sets: removing a non-real `u`-only content factor removes
no real point, and splitting a shared factor `h` from `f = h a`, `g = h b` replaces
`{f=0} union {g=0}` by `{h=0} union {a=0} union {b=0}`, which is the same set. Labels are
recomputed from the original quadrics, and the final arrangement is certified against the
original pullbacks, so the basis is a construction aid rather than a change of semantics.

### 4.4 Determinism

The kernel uses deterministic containers, fixed seeds, canonical sorting, and no f64
decisions. Lean proves canonical order uniqueness, merge-sort determinism, label multiset
invariance, and injective base-4 label encoding. Rust checks two-run equality and
byte-stable artifacts; CI checks the same outputs across platforms.

### 4.5 What is proved, checked, measured, and assumed

- **Proved**: `checkMatch` iff, `openEdges` closure, label multiset/injective encoding,
  `NoneReason` totality, cusp branch sign, interval comparator order axioms, Euler
  parity/duality/tree, and the analytic boundedness core.
- **Checked**: five extracted Rust scenes for closure and Euler; negative controls.
- **Measured**: completeness, adversarial cases, external oracle, ablation, scale.
- **Assumed**: the full arrangement construction is not formally verified; the general
  planar genus-zero theorem is not formalized; the polynomial leading-term reduction and
  the general Taylor `O(4)` truncation are paper-level arguments.

The Lean development has no `sorryAx` in its main theorems; the two layers (Mathlib-free
and Mathlib) are checked separately.

## 5. Completeness Evaluation

### 5.1 Two layers

The single-chart diagnostic fixes one chart and measures rejection; it isolates soundness
and degeneracy handling. The multi-chart product path measures residual all-chart
rejection and practical completeness. Mixing them would hide the atlas effect.

### 5.2 Single-chart diagnostic

The single-chart diagnostic rejects 378 inputs: 364 non-bounded charts and 14 confluent
components, with zero unclassified. On product geometry, the circle family closes
8000/8000; the ellipsoid-plane family records `ok=1617`, `none=14`, all 14 explainable by a
degenerate class, with zero general-position rejections.

The population is 10,000 generated cases: 8,000 random circle arrangements and 2,000
ellipsoid-plane scenes. After filtering (undefined ellipsoid, fewer than two curves,
non-quadratic-in-`v` pullback, duplicate planes), 9,631 are attempted (8,000 circle and
1,631 ellipsoid-plane); the 378 rejections refer to this attempted set. The 369 filtered
ellipsoid-plane cases are not counted as successes or failures.

### 5.3 Atlas residual and ablation

The atlas has six axial and twenty-four general poles. On 5000 fixed-seed cases per
coefficient height `H`, the residual all-chart rejection rate is below. Each case uses two
or three random planes on a random rational ellipsoid: this is a plane-family benchmark,
not a general-quadric benchmark. The mixed quartic family is evaluated separately.

| `H` | cases | `None` | rate |
|---|---|---|---|
| 1 | 5000 | 749 | 14.98% |
| 3 | 5000 | 32 | 0.64% |
| 10 | 5000 | 1 | 0.020% |
| 20 | 5000 | 0 | 0.000% |

The trend is consistent with an empirical `O(1/H)` behavior, not a theorem. On 2000
two-to-three-plane cases a common safe pole exists in all 2000 (average 25.64 of 30 poles
safe); a synthetic worst case with 30 covering planes has zero safe poles.

The ablation isolates chart switching. The plane `x=0` is non-bounded in the base chart
but the atlas resolves it (`V/E/F=2/2/2`). Two vertical planes are non-bounded in the base
chart and are resolved (`V/E/F=6/8/4`). A plane tangent at the excluded pole is rejected by
the atlas as well (fail-closed).

### 5.4 Quartic pullbacks and single-safe-chart lift

For the 20 mixed quadric pullbacks at `H=2`, the standard chart closes 14. The six
failures are all non-bounded; the undetermined count is zero. Appendix A gives the per-case
details: degree, degree in `v`, boundedness, singularity, and separate `detected` and
`reject_reason` fields. A row with `result=ok` may carry a `detected` tag (e.g.,
`singular-point`) that is distinct from `reject_reason`; a detected singularity that is
resolved is not a rejection.

The 3D-face-check mode uses the same 6+24 candidate pool as the single-chart path. An
earlier version closed 17/20: cases 2 and 17 were lost and case 13 was unresolved because
an empty quadric aborted the whole search and a common-component chart aborted its search.
After making these gates per-chart (skip an empty quadric; continue past a
common-component chart) and certifying each accepted candidate, the 3D-face-check mode
closes **20/20 certified**. Case 2 has one empty quadric, case 13 switches away from a pole
on the cylinder, and case 17 has a figure-eight node; all three are handled by the same
candidate pool. This mode still reconstructs **one** chart per output; it does not stitch
different charts.

**Table 4b.** Quartic closing rates by method (2-quadric 20-case benchmark).

| method | closes | note |
|---|---:|---|
| standard chart | 14/20 | 6 non-bounded |
| 6+24 chart search + 3D face-point check | **20/20** | certified; one chart per output |
| single safe chart 2D lift | **20/20** | certified; strict 20/20 |
| last-resort 3D check | **0/20** | not invoked on this benchmark |

All rows use the same 6+24 candidate pool; the difference is the reconstruction and
acceptance check. The single-safe-chart 2D lift is preferred because it uses the exact 2D
labels and compactifies the unbounded face at the pole. Genuine multi-chart stitching is
not implemented (OP2).

A **20-case three-quadric pilot** (same seed family, `H=2`) is the first test with
triple-point potential: 12/20 close via the primary single-chart path and 8/20 via
transform/basis fallbacks; all 20 are certified and strict, and the last-resort 3D check
is 0/20. The earlier 18/2 split disappeared after removing a duplicate chart-preparation
pass: the old code zipped charts sorted by the general key with keys sorted by the plane
key, so an all-plane case could pair a chart with the wrong priority key. The corrected
path uses `chart` and `key` from the same prepared entry.

A **100-case three-quadric stress test** (8 parallel workers, 300 s per case) is the
larger check. With the deterministic survey budget, exact 2D chart transforms, and the
basis fallback, it closes **100/100**, certified **100/100**, strict **100/100**, with no
timeout. The former failures 31 (`cone+cone+cylinder`) and 66
(`cylinder+cylinder+plane`) and the former timeouts 12 and 57 all pass. In this family 61
cases use the primary single-chart path, 37 require only a rational linear transform, and
2 require the square-free coprime basis; the basis+linear and last-resort 3D stages are not
needed. This is still an empirical result on a fixed-seed, `H=2` family, not an
unconditional three-quadric theorem.

**Table 4c.** Three-quadric 100-case stress (8 parallel workers, 300 s/case).

| method | closes | certified | strict | timeout |
|---|---:|---:|---:|---:|
| hybrid (single + transform/basis fallback) | **100/100** | **100/100** | **100/100** | **0** |
| primary single-chart only | 61/100 | — | — | — |
| transform/basis fallback | 39/100 | — | — | — |

Latency in this 8-worker run: median 9.2 s, maximum 104.0 s; 13 cases exceed 30 s, three
exceed 60 s, and none exceeds 120 s. The tail is dominated by cases that try several
transformed charts before a strict-valid candidate. Moving the det-2 shear earlier reduced
case 57 from 126 s to 64 s in the same harness. An additional early exit — if `Res_v(F,G)`
has no real root, the pair cannot intersect, so `Res_u` and the `v` root isolation are
skipped — reduced case 38 from 88 s to 31 s single-job. A sequential 20-case pilot gives
median 6.3 s and maximum 31.7 s.

**Table 4d.** Fallback attribution for the 100-case stress.

| stage that produced the accepted output | cases | notes |
|---|---:|---|
| primary single-chart | 61 | includes cases with intermediate budget pruning |
| rational 2D linear transform | 37 | rotations and shears; 12/38/57/79/99 are examples |
| square-free coprime basis | 2 | 31 and 66 |
| basis + linear transform | 0 | not needed |
| last-resort 3D check | 0 | not needed |

The diagnostic `SurveyBudget` counter records 9,651 rejected intermediate operations
across 82 cases, but **no case failed solely because of `BudgetExceeded`**; the counter
prunes candidate resultants/roots and the search continues. Cases 31 and 66 need the basis
(0 budget hits); the former timeouts 12 and 57 need the linear transform. This addresses
the natural question of whether the 100/100 result is just a budget cutoff: it is not.

The attribution is not a monotone ablation, because each stage is a complete search rather
than a filter; it does show that neither the linear stage (37 cases) nor the basis stage
(2 cases) is redundant on this family. Basis+linear and the last-resort 3D check contribute
zero accepted outputs, so the 100/100 result is obtained by the first three stages alone.

**Table 4e.** Budget/transform sensitivity pilot. `P64`...`P1024` are the primary
single-chart budget in resultant bits; `L`/`Lrev` are the linear stage with forward/reverse
transform order; `B` is the basis stage. A checkmark means the stage produced a
certified+strict output within the run; seconds are wall-clock in that run.

| case | P64 | P128 | P256 | P1024 | L | Lrev | B | accepted stage |
|---|---:|---:|---:|---:|---|---|---|---|
| 0-3 (pilot) | ok | ok | ok | ok | ok | ok | ok | primary |
| 12 | fail | fail | ok (76 s) | ok (75 s) | ok (27 s) | ok (69 s) | ok (79 s) | linear |
| 31 | fail | fail | fail | fail | fail | fail | ok (49 s) | basis |
| 66 | fail | fail | fail | fail | fail | fail | ok (0.35 s) | basis |

Two conclusions are already visible. First, the budget is not a binary success switch:
case 12 needs at least 256 bits in the primary path but is solved faster by the linear stage
at 64 bits. Case 31/66 are budget-insensitive and need the basis. Second, transform order
affects latency (27 s vs 69 s on case 12) but not the accepted set in this pilot; case 57
needs the det-2 shear and is too slow for the full 7-way ablation; we report its accepted
path from Table 4d and the 126 s -> 64 s improvement from moving that shear earlier.

### 5.5 External oracle and certificate checks

We cross-check intersection counts on six fixed cases against SymPy: general (2), external
tangency (1), internal tangency (1), concentric (0), triple point (4), and quartic plus
conic (4). The Rust counts match. The certificate checker accepts representative
arrangements and rejects tampered labels, component counts, and rotation systems.

### 5.6 Scale and negative results

The scale probe over circle arrangements `N=2..7` closes all cases with the certificate
passing; wall times range from 1.9 ms to 167 ms. These numbers demonstrate practical
behavior on the tested family, not a general complexity bound.

The 20 two-quadric cases take 0.03–7.1 s end-to-end including certificate and strict
checks (median 2.3 s, total 49.0 s on the reference machine, one job). Removing the
duplicate chart-preparation pass cut the earlier end-to-end median from 3.9 s to 2.2 s.
The 100-case three-quadric sweep no longer times out; its latency tail is reported in
Table 4c.

A stage profile after that fix attributes **46% to chart preparation, 52% to 2D
arrangement, and under 1% to the 2D certificate, 3D lift, full certificate, and strict
check combined**. The end-to-end gap is therefore chart search/pullback and 2D
construction, not strict post-hoc checking. This is why the quartic benchmark stays at
20 cases and why the three-quadric run is a pilot rather than a large corpus.

The four-plane case is resolved by the same single-chart lift: 4-plane **20/20**
certified (example C1 `V/E/F=20/32/14`). The earlier shared face-cycle check produced mixed
boundary signs at rationally approximated 3D vertices; this was a checker false positive,
not a topology error. A strict loop-boundary check (exact interval evaluation at 2D
vertices) passes 20/20 on 3/4/5/6-plane and quartic benchmarks; a general proof of the
strict check remains future work. The certified claim uses exact 2D face points, exact
3D face-point signs, and the benchmark-verified strict check. Seven or more planes are out
of scope. Four general quadrics remain out of scope. Mesh fidelity is best-effort.

## 6. 3D Arrangement and Application

### 6.1 Ellipsoid plus three to six planes

For an ellipsoid plus three planes in 20 general-position cases, the certified kernel
closes 20/20 with max `V/E/F=12/18/8`. Four planes also close 20/20 (example C1:
`V/E/F=20/32/14`). The same single-chart lift covers five and six planes: both families
close **20/20** certified and strict, with max `V/E/F=30/50/22` (5 planes) and
`42/72/32` (6 planes). Per-case latency over these 20-case families is 36.8 ms (3 planes),
75.0 ms (4), 126.5 ms (5), and 185.3 ms (6) median; the maximum is 245 ms and peak process
working set is about 6.9 MB. Every face point lies on the ellipsoid, every face label matches the
exact plane signs, and two runs agree. Plane-ellipsoid intersections are circles (conics)
in the pullback, so this family is a **baseline** for the pipeline and face labels, not
evidence for general quartic 3D; the quartic single-chart lift is the relevant test. The
certified plane API explicitly gates `planes.len() > 6` and returns `OutOfScope`;
this is a validation-scope label, not a face-cycle failure and not a budget cutoff (the
distinction is explained in Section 3.5). The single-chart
lift itself is n-agnostic; seven or more planes are outside the validated corpus.

### 6.2 Band scene

The band scene is the unit sphere cut by two parallel planes `z=+1/2` and `z=-1/2`; the
central face is an annulus with two loops. It closes with 64 triangles, half-edge pairing
`(0,0)`, exact counts `(64,0,0)`, and zero self-intersections. It is a baseline for the
exact manifold path; the mesh is not claimed to be optimal or seam-free.

### 6.3 Auxiliary 2D slicer

The kernel can drive an exact 2D slicer: boundary arcs are split at exact intersection
points and can be exported to SVG or DXF. This is auxiliary and not used to support the
main evaluation.

### 6.4 Certificate checker

The checker is the bridge between "the kernel returned something" and "the returned object
is independently checkable." It is deliberately small and separate from the generator. Its
negative tests are as important as its positive tests. The checker does not prove that the
generator is complete; it proves that accepted outputs satisfy the stated invariants. A
two-phase API prototype separates Phase 1 (fast topology and non-strict certificate) from
Phase 2 (strict loop-boundary check); Phase 1 is for preview/topology consumers, and Phase 2
is the audit gate.

## 7. Limitations

- **No unconditional completeness.** The kernel can return `Rejected(None(reason))` or
  `Undetermined`; the claim is soundness plus empirical practical completeness.
- **Seven or more planes are out of scope.** 3/4/5/6-plane families are certified 20/20
  under the scoped certificate and strict check. The earlier shared face-cycle check was a
  false positive due to rationally approximated vertices; the certified claim uses exact 2D
  face points and exact 3D face-point signs.
- **Four general quadrics are out of scope.**
- **Quartic pullbacks:** the 2-quadric benchmark is standard 14/20; the 3D-face-check
  mode is 20/20 certified; the single-safe-chart 2D lift is 20/20 certified, with
  last-resort 3D check 0/20. The 3-quadric pilot and the 100-case stress test are 100/100
  certified and strict, with no timeout under the 300 s/case harness; 39/100 use a
  transform or basis fallback. This is still an empirical fixed-seed result, not a general
  three-quadric claim. The lift requires a
  common safe chart or a transform that makes the chart tractable; without either, true
  multi-chart stitching remains future work (OP2).
- **`O(1/H)` is empirical**, measured on the 2–3 plane family with a fixed seed; it is not
  a theorem.
- **No head-to-head benchmark.** We do not compare wall-clock time or memory against CGAL or
  other exact arrangement implementations; the evaluation is internal and fixed-seed.
- **Mesh fidelity is best-effort**; arc-seam artifacts remain.
- **Lean coverage is partial**; the full arrangement construction is not verified.

### 7.1 Open problems

| ID | Problem | Current status | Remaining work |
|---|---|---|---|
| OP1 | Strict loop-boundary certificate for 3D face cycles | local checker Lean-formalized; passes 20/20 on 3/4/5/6-plane and quartic benchmarks | geometric bridge/edge-splitting proof and full formalization |
| OP2 | Multi-chart stitching without a common safe chart | single chart preferred; 3D-face-check limited; true multi-chart stitching unimplemented | arbitrary-scene stitching and completeness |
| OP3 | General four quadrics / seven-plus surfaces | out of scope | fourth-degree space curves, triple/quadruple points |
| OP4 | Unconditional termination and cost bounds | resource limits / `Undetermined` possible | termination and cost theorem for the class |
| OP5 | Lean coverage | combinatorial core + extracted data + Mathlib lemmas | extend coverage; full formalization is not planned |
| OP6 | Performance and scaling | 20/5000-case benchmark, small scenes | CAD-scale scenes, comparison with certified MT |

We avoid phrases such as "solves all inputs," "complete for arbitrary degeneracies,"
"guarantees watertight meshes," and "formally verified arrangement construction."

## 8. Related Work

Prior work has established exact 3D quadric arrangements [Mourrain-Tecourt-Teillaud 2005],
complete planar maps of quadric intersection curves [Berberich et al. 2005], exact cell
computation including degenerate cases [Schomer-Wolpert 2006], exact low-degree curve
arrangements and conic booleans [Exacus 2005], general exact arrangement frameworks [CGAL],
exact boundary evaluation [ESOLID], isotopy-guaranteed implicit meshing
[Plantinga-Vegter 2004/2007], and a complete QSIC classification via signature sequences
[Tu et al. 2009]. Near-optimal parameterization of quadric intersections is addressed by
Dupont et al., exact mesh CSG by Levy (2025), and CGAL's `Arrangement_on_surface_2`
(including surface traits); the verified 3D mesh-intersection work is available as an open
repository (schildep, 2026). We do not claim a new arrangement algorithm or a new
classification.

Exact arrangements of quartic curves and implicitly defined real algebraic plane curves are
treated by Caravantes and Gonzalez-Vega [2007, 2008], and complete arrangements of cubic curves
with all degeneracies by Eigenwillig et al. [2006]. Our C4 benchmark is a scoped evaluation of
a quadric-pullback pipeline, not a new quartic arrangement algorithm. The specific contribution
of C5 is a specific exact membership test, not the general avoidance of irrational numbers,
which is already present in [Caravantes–Gonzalez-Vega 2008].

Arrangements on parametric surfaces and exact spherical arrangements are established by
Berberich et al. [2007, 2010], Cazals and Loriot [2009], de Castro et al. [2009], and Fogel
[2009]. The classical stereographic parameterization of quadrics and its rational
reparameterizations are analyzed by Wang, Joe, and Goldman [1997]. Our rational atlas uses
these classical charts; the delta is the deterministic 6+24 pole atlas, the interval-Möbius
vertex identity, and the empirical `O(1/H)` residual.

Formal-methods CSG is explored by Tzoumas et al. [2015], who apply interval analysis and proof
assistants to CSG models. Certifying algorithms and untrusted-certificate architectures are
established by McConnell et al. [2011] and Li, Passmore, and Paulson [2019]. Our contribution
is the specific checker for Euler/face signs/rotation and the quadric-arrangement application,
not the general idea of certification.

Separation bounds for real algebraic expressions and root comparison are classical
[Burnikel et al. 2009; Emiris–Mourrain–Tsigaridas 2010]. Formal planar subdivisions, Euler
formula, and discrete Jordan curve theorem are formalized with combinatorial hypermaps by
Dufourd [2008, 2009]. Our Lean layer is partial and targets the half-edge/closure/Euler
bookkeeping, not a full planar-map formalization.

A companion technical report (S4) covers the sphere-plus-plane specialization and its Lean
combinatorial closure. S5 is not a superset of that report: it adds general quadric
pullbacks, the 6+24 atlas, ordinary-cusp handling, the certified 3-6-plane gate, and the
single-safe-chart lift. The shared Lean core is the half-edge/closure/Euler bookkeeping;
S5-specific Lean is `S5Strict.lean`, the Mathlib cusp/boundedness lemmas, and the quartic
extracted-data checks.

Our difference is the combination of guarantees: a rational multi-chart atlas for
unbounded pullbacks, a classified `NoneReason` for every rejection, an independent
certificate checker, deterministic and reproducible artifacts, and a partially formalized
combinatorial core. ESOLID explicitly does not support degenerate Boolean configurations;
we make degeneracy handling explicit, but our scope is narrower. The Lean-verified
mesh-intersection work provides stronger end-to-end verification for triangle meshes; our
target is quadric arrangements and our Lean coverage is partial.

The positioning is deliberate: compare us on the guarantees we actually provide, not on a
claim of general superiority.

## 9. Reproducibility

- **Artifacts.** `data/artifacts/` contains raw stdout and SHA-256 records. Quartic
  2-quadric benchmark: standard 14/20, 3D-face-check mode 20/20 certified, single-chart lift 20/20
  certified/strict, fallback 0/20. Three-quadric pilot: hybrid 20/20 certified/strict;
  the 100-case stress test is 100/100 certified/strict with no timeout. Plane families:
  3/4/5/6-plane 20/20 certified/strict, median 36.8/75.0/126.5/185.3 ms. The P1/P2 record
  the 100-case stress test is 100/100 certified/strict with no timeout. Plane families:
  3/4/5/6-plane 20/20 certified/strict, median 36.8/75.0/126.5/185.3 ms. The P1/P2
  results are summarised in `data/artifacts/s5_p1p2_results.csv`; the sweeps are
  `s5_quadrics_hybrid_3q_100_p1p2_2026-10-24.txt`,
  `s5_quadrics_hybrid_2q_20_seq_p1p2_2026-10-24.txt`, and
  `s5_quadrics_hybrid_3q_100_strategy_2026-10-24.txt`; the stage profile is
  `s5_quadrics_profile_2026-10-24.txt`. `SHA256SUMS` covers every artifact in this
  record.
- **Rust tests.** `s5_certificate`, `s5_adversarial`, `s5_sympy_oracle`, `s5_ablation`,
  `s5_horizontal`, `s5_arrangement`, `s5_curve2d`, `s5_quadrics_hybrid`, `s5_two_phase`,
  `fuzz_s5`. Correctness sweeps use the parallel harness; latency is measured with one job.
- **Lean.** The Mathlib-free core and the Rust-to-Lean extraction are checked for
  `sorryAx`, and the Mathlib files are checked separately. The Lean sources are not
  included in this artifact.
- **CI.** Ubuntu, macOS x86, macOS arm64, and Windows; byte-stable artifacts and tests.
- **Environment.** AMD Ryzen 7 5700X (8 cores / 16 threads), 64 GB RAM, Windows 11,
  rustc 1.98.0, release profile. Timings are indicative.
- **Randomness.** Fixed-seed xorshift64*; mixed quartic coefficients uniform over integer
  ranges determined by `H`; the `H` benchmark uses two or three planes with integer normals
  and offsets on a random rational ellipsoid.

### 9.1 Benchmark protocol

- Mixed quartic family: fixed seed, `H=2`, two quadrics per case, 20 cases.
- Atlas family: 5000 fixed-seed cases per `H`, two or three planes per case.
- 3/4/5/6-plane families: 20 deterministic cases each.
- Failure corpus: seven or more planes, general four quadrics, and strict-check cases.
- Inputs are deterministic and fixed-seed; the reported counts are recorded in the
artifact data so the same benchmark can be reconstructed.

This artifact includes the artifact data and the SHA-256 list. The paper does not rely
on a proprietary dataset. The research kernel and proofs are independent of the Axiom
product QA core; the product boundary is described in Section 9.2.

### 9.2 Code and data availability

**Code.** The S5 research kernel, tests, examples, and Lean/Mathlib proofs are not
included in this paper/data artifact. No code license is granted by this artifact.

**Product boundary.** The Axiom product QA core, MCP server, CLI, and CA signing
service are separate from this paper and are not included in this artifact. Their
licensing is separate and is not determined by this artifact. No proprietary A'
source or CA signing key is included. None of the S5 results depend on the product.

**Data.** All benchmark families are synthetic and fixed-seed: the 2-3-plane atlas
family (5000 cases per `H`), the 2-quadric 20-case family, the 3-quadric 20/100-case
families, and the 3/4/5/6-plane 20-case families. Inputs are deterministic. No
proprietary, personal, or third-party restricted data are used. SymPy is an optional
independent oracle; CGAL is not used for S5 claims.

**Certificate and verification.** The S5 certificate is the runtime checker
`certify_planar_arrangement_n` (and its strict variant); its tests include four accepted
arrangements and three tampered arrangements that must be rejected. The checker
construction is described in this paper; its implementation is not included in this
artifact. The Axiom-signed certificate schema is open. Axiom-signed certificates are
not used as S5 evidence.

**License.** Paper text: CC BY 4.0. Artifact data: CC BY 4.0. Third-party tools keep
their own licenses. No research code, Lean source, product source, MCP server, CLI, or
CA signing key is included in this artifact.

### 9.3 Reproducibility scope

All reported algorithmic results and benchmark counts are recorded in this data
artifact: the atlas rejection counts, the 2-quadric 20/20 and 3-quadric 100/100
certified/strict results, the 3/4/5/6-plane 20/20 results, the SymPy cross-checks, and
the Lean checks. Timing, parallel speed-up, and peak-RSS values depend on the host and
worker count and are not bit-reproducible. Axiom-signed certificates and the Axiom
product QA core are outside the reproducibility scope of S5; no S5 claim depends on
them. Test vectors are included under `data/artifacts/test-vectors/`.

## Appendix A. Per-case quartic details

**Table 4.** Per-case quartic details. `curve1` and `curve2` report degree / degree in `v` /
boundedness / singularity. `detected` is a tag on an accepted case; `reject_reason` is a
`NoneReason` on a rejected case. Legend: B/U = bounded/unbounded, S/NS = singular/non-singular, NB = NonBoundedChart, sing = singular-point.

| case | kinds | result | detected | reject_reason | curve1 | curve2 |
|---:|---|---|---|---|---|---|
| 0 | cylinder+plane | none | - | NB | 3/3/U/NS | 2/2/B/NS |
| 1 | cylinder+cylinder | none | - | NB | 4/4/B/NS | 3/3/U/NS |
| 2 | cone+general | ok | - | - | 4/4/B/NS | 4/4/B/NS |
| 3 | cone+plane | ok | - | - | 2/2/B/NS | 4/4/B/NS |
| 4 | cylinder+cylinder | none | - | NB | 4/4/B/NS | 3/2/U/NS |
| 5 | general+plane | ok | - | - | 4/4/B/NS | 2/2/B/NS |
| 6 | cone+general | ok | - | - | 4/4/B/NS | 4/4/B/NS |
| 7 | cone+plane | ok | sing | - | 2/2/B/NS | 4/4/B/S |
| 8 | cone+cylinder | ok | sing | - | 2/2/B/S | 4/4/B/NS |
| 9 | cone+cone | ok | sing | - | 4/4/B/NS | 4/4/B/S |
| 10 | general+general | ok | - | - | 4/4/B/NS | 4/4/B/NS |
| 11 | plane+plane | none | - | NB | 1/1/U/NS | 2/2/B/NS |
| 12 | cone+plane | ok | - | - | 2/2/B/NS | 4/4/B/NS |
| 13 | cylinder+general | none | - | NB | 4/4/B/NS | 3/3/U/NS |
| 14 | cone+cone | ok | - | - | 4/4/B/NS | 4/4/B/NS |
| 15 | cylinder+general | ok | - | - | 4/4/B/NS | 4/4/B/NS |
| 16 | general+plane | ok | - | - | 2/2/B/NS | 4/4/B/NS |
| 17 | cylinder+general | ok | sing | - | 4/4/B/NS | 4/4/B/S |
| 18 | cylinder+plane | none | - | NB | 4/4/B/S | 1/1/U/NS |
| 19 | cone+general | ok | - | - | 4/4/B/NS | 4/4/B/NS |

This table is the 2-quadric benchmark: the 3D-face-check mode and the single-safe-chart
2D lift both close all 20, and the last-resort 3D check is not invoked (0/20). The separate 3-quadric pilot is
hybrid 20/20 certified/strict. The 100-case stress test is not shown per case; it closes
100/100 with 100/100 certified and strict and no timeout. Cases 31, 66, 12, and 57, which
failed or timed out before the deterministic-budget and transform/basis work, all pass.

## References (selected)

- Mourrain, B., Tecourt, J.-P., Teillaud, M. On the computation of an arrangement of quadrics in 3D. Computational Geometry: Theory and Applications 30(2):145-164, 2005.
- Berberich, E., Hemmer, M., Kettner, L., Schomer, E., Wolpert, N. An exact, complete and efficient implementation for computing planar maps of quadric intersection curves. SoCG 2005, pp. 99-106.
- Schomer, E., Wolpert, N. An exact and efficient approach for computing a cell in an arrangement of quadrics. Computational Geometry: Theory and Applications 33(1-2):65-97, 2006.
- Berberich, E., et al. EXACUS: Efficient and exact algorithms for curves and surfaces. ESA 2005, LNCS 3669:155-166.
- CGAL. 2D Arrangements User Manual (Arrangement_on_surface_2), 2026.
- Keyser, J., Culver, T., Foskey, M., Krishnan, S., Manocha, D. ESOLID: a system for exact boundary evaluation. Computer-Aided Design 36(2):175-193, 2004.
- Tu, C., Wang, W., Mourrain, B., Wang, J. Using signature sequences to classify intersection curves of two quadrics. Computer Aided Geometric Design 26(3):317-335, 2009.
- Plantinga, S., Vegter, G. Isotopic approximation of implicit curves and surfaces. SGP 2004; Isotopic meshing of implicit surfaces. The Visual Computer 23(1):45-58, 2007.
- Dupont, L., Lazard, D., Lazard, S., Petitjean, S. Near-optimal parameterization of the intersection of quadrics. SoCG 2003; Journal of Symbolic Computation 43(3):168-191, 2008.
- Levy, B. Exact predicates, exact constructions and combinatorics for mesh CSG. arXiv:2405.12949, 2025.
- schildep. verified-3d-mesh-intersection: Formally verified 3D mesh intersection. GitHub repository, 2026.
- S4 companion. Sphere-plus-plane specialization and Lean combinatorial closure. Companion preprint, 2026. DOI: 10.5281/zenodo.23721477.
- Caravantes, J., Gonzalez-Vega, L. Computing the topology of an arrangement of quartics. Mathematics of Surfaces XII, LNCS 4647:104-120, 2007. DOI: 10.1007/978-3-540-73843-5_7.
- Caravantes, J., Gonzalez-Vega, L. Computing the topology of an arrangement of implicitly defined real algebraic plane curves. Journal of Zhejiang University Science A, 9(12):1685-1693, 2008. DOI: 10.1631/jzus.a08gmp01.
- Eigenwillig, A., Kettner, L., Schomer, E., Wolpert, N. Exact, efficient, and complete arrangement computation for cubic curves. Computational Geometry, 35(1-2):36-73, 2006. DOI: 10.1016/j.comgeo.2005.10.003.
- Berberich, E., Fogel, E., Halperin, D., Mehlhorn, K., Wein, R. Sweeping and maintaining two-dimensional arrangements on surfaces: A first step. ESA 2007, LNCS 4698:645-656. DOI: 10.1007/978-3-540-75520-3_57.
- Berberich, E., Fogel, E., Halperin, D., Mehlhorn, K., Wein, R. Arrangements on parametric surfaces I: General framework and infrastructure. Mathematics in Computer Science, 4(1):45-66, 2010. DOI: 10.1007/s11786-010-0042-5.
- Berberich, E., Fogel, E., Halperin, D., Kerber, M., Setter, O. Arrangements on parametric surfaces II: Concretizations and applications. Mathematics in Computer Science, 4(1):67-91, 2010. DOI: 10.1007/s11786-010-0043-4.
- Wang, W., Joe, B., Goldman, R. Rational quadratic parameterizations of quadrics. International Journal of Computational Geometry & Applications, 7(6):599-619, 1997. DOI: 10.1142/S0218195997000375.
- Cazals, F., Loriot, S. Computing the arrangement of circles on a sphere, with applications in structural biology. Computational Geometry, 42(6-7):551-565, 2009. DOI: 10.1016/j.comgeo.2008.10.004.
- de Castro, P. M. M., Cazals, F., Loriot, S., Teillaud, M. Design of the CGAL 3D spherical kernel and application to arrangements of circles on a sphere. Computational Geometry, 42(6-7):536-550, 2009. DOI: 10.1016/j.comgeo.2008.10.003.
- Fogel, E. Minkowski sum construction and other applications of arrangements of geodesic arcs on the sphere. arXiv:0906.3240, 2009.
- Tzoumas, G., Michelucci, D., Foufou, S. Extending CSG with projections: Towards formally certified geometric modeling. Computer-Aided Design, 66:45-54, 2015. DOI: 10.1016/j.cad.2015.04.003.
- Burnikel, C., Funke, S., Mehlhorn, K., Schirra, S., Schmitt, S. A separation bound for real algebraic expressions. Algorithmica, 55(1):14-28, 2009. DOI: 10.1007/s00453-007-9132-4.
- Emiris, I. Z., Mourrain, B., Tsigaridas, E. P. The DMM bound: multivariate (aggregate) separation bounds. ISSAC 2010, 243-250. DOI: 10.1145/1837934.1837981.
- McConnell, R. M., Mehlhorn, K., Naher, S., Schweitzer, P. Certifying algorithms. Computer Science Review, 5(2):119-161, 2011. DOI: 10.1016/j.cosrev.2010.09.009.
- Li, W., Passmore, G. O., Paulson, L. C. Deciding univariate polynomial problems using untrusted certificates in Isabelle/HOL. Journal of Automated Reasoning, 62(1):69-91, 2019. DOI: 10.1007/s10817-017-9424-6.
- Dufourd, J.-F. Polyhedra genus theorem and Euler formula: A hypermap-formalized intuitionistic proof. Theoretical Computer Science, 403(2-3):133-159, 2008. DOI: 10.1016/j.tcs.2008.02.012.
- Dufourd, J.-F. An intuitionistic proof of a discrete form of the Jordan curve theorem formalized in Coq with combinatorial hypermaps. Journal of Automated Reasoning, 43(1):19-51, 2009. DOI: 10.1007/s10817-009-9117-x.
